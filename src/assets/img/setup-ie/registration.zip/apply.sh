#!/usr/bin/env bash


common_apply() {
    # apply rbac
    helm upgrade --install nfs-rbac remote-node/raw -f resources/nfs-rbac.yaml
    # apply nfs pvc
    helm upgrade --install nfs-pvc remote-node/raw -f resources/nfs-pvc.yaml

    # install rn components
    mh apply -c main.yaml
}

sdp_last() {
    helm upgrade --install kafka-secure remote-node/raw -f resources/kafka-secure.yaml
}

if [[ $1 == "sdp" ]]; then
   common_apply
   sdp_last

elif [[ $1 == "ie" ]]; then
    common_apply
fi

