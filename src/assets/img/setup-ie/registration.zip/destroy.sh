#!/usr/bin/env bash


common_destroy() {
    # destroy RN
    mh destroy -c main.yaml

    # remove nfs pvc
    helm delete --purge nfs-pvc

    # remove nfs-rbac
    helm delete --purge nfs-rbac
}

sdp_last() {
    helm delete --purge kafka-secure
}


if [[ $1 == "sdp" ]]; then
   common_destroy
   sdp_last

elif [[ $1 == "ie" ]]; then
    common_destroy
fi


